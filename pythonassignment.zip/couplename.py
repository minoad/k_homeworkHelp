name_1 = "katie"
name_2 = "regan"

couple_name = name_1 + name_2
print capitalized(couple_name)

#I am getting a syntax error on the capitalized. 
#My textbook lists capitalize() as a funtion.
#When I began typing it, capitalized, with the d at the end came up
#I tried both but both return a syntax error
#I also tried putting it with the couple_name assignment; couple_name = capitalize(name_1 + name_2)


